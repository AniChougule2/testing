from fastapi import FastAPI
from app.models import ValidationRequest, ValidationResponse, ValidationIssue
from app.parser import analyze_sql, extract_source_and_target_objects
from app.validator import validate_sql

app = FastAPI(
    title="SQL Validation Agent MVP",
    description="API for validating source-to-target SQL logic using schema metadata and mappings.",
    version="0.1.0",
)


@app.get("/health")
def health() -> dict:
    return {"status": "ok"}


@app.post("/parse")
def parse_endpoint(payload: dict) -> dict:
    sql = payload.get("sql", "")
    dialect = payload.get("dialect", "bigquery")
    return analyze_sql(sql, dialect=dialect)


@app.post("/extract-objects")
def extract_objects(payload: dict) -> dict:
    source_sql = payload.get("source_sql", "")
    target_sql = payload.get("target_sql", "")

    return extract_source_and_target_objects(source_sql, target_sql)


@app.post("/validate", response_model=ValidationResponse)
def validate(request: ValidationRequest) -> ValidationResponse:
    result = validate_sql(
        source_sql=request.source_sql,
        target_sql=request.target_sql,
        source_schema=request.source_schema,
        target_schema=request.target_schema,
        mappings=request.mappings,
    )

    return ValidationResponse(
        status="success",
        issues=[ValidationIssue(**issue) for issue in result["issues"]],
        summary=result["summary"],
    )