from typing import Any, Dict, List
import sqlglot
from sqlglot import exp


def parse_sql(sql: str) -> exp.Expression:
    """
    Parse SQL into a sqlglot expression tree.
    """
    return sqlglot.parse_one(sql)


def extract_select_columns(parsed: exp.Expression) -> List[str]:
    """
    Extract selected columns/aliases from the SELECT clause.
    """
    columns = []

    select_exprs = parsed.expressions or []
    for item in select_exprs:
        alias = item.alias_or_name
        if alias:
            columns.append(alias)
        else:
            columns.append(item.sql())

    return columns


def extract_tables(parsed: exp.Expression) -> List[str]:
    """
    Extract physical table names referenced in the query.
    """
    tables = []

    for table in parsed.find_all(exp.Table):
        table_name = table.sql()
        if table_name not in tables:
            tables.append(table_name)

    return tables


def extract_joins(parsed: exp.Expression) -> List[Dict[str, Any]]:
    """
    Extract join type, table, and join condition.
    """
    joins = []

    for join in parsed.find_all(exp.Join):
        joins.append(
            {
                "join_type": join.args.get("kind", "JOIN"),
                "table": join.this.sql() if join.this else None,
                "condition": join.args.get("on").sql() if join.args.get("on") else None,
            }
        )

    return joins


def extract_where_clause(parsed: exp.Expression) -> str | None:
    """
    Extract WHERE clause if present.
    """
    where = parsed.args.get("where")
    return where.sql() if where else None


def extract_functions(parsed: exp.Expression) -> List[str]:
    """
    Extract SQL functions used in the query.
    Example: CAST, TRIM, COALESCE
    """
    functions = []

    for node in parsed.walk():
        if isinstance(node, exp.Func):
            func_name = node.sql_name()
            if func_name not in functions:
                functions.append(func_name)

    return functions


def analyze_sql(sql: str) -> Dict[str, Any]:
    """
    Parse and return a structured summary of the SQL.
    """
    parsed = parse_sql(sql)

    return {
        "columns": extract_select_columns(parsed),
        "tables": extract_tables(parsed),
        "joins": extract_joins(parsed),
        "where": extract_where_clause(parsed),
        "functions": extract_functions(parsed),
    }


def extract_source_and_target_objects(source_sql: str, target_sql: str) -> Dict[str, List[str]]:
    """
    Extract referenced table/object names from both source and target SQL.
    """
    source_analysis = analyze_sql(source_sql)
    target_analysis = analyze_sql(target_sql)

    return {
        "source_objects": source_analysis["tables"],
        "target_objects": target_analysis["tables"],
    }