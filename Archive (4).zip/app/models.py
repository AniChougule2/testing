from typing import List, Optional, Literal
from pydantic import BaseModel, Field


class ColumnMetadata(BaseModel):
    name: str = Field(..., description="Column name")
    datatype: str = Field(..., description="Column datatype")


class TableSchema(BaseModel):
    table_name: str = Field(..., description="Table name")
    columns: List[ColumnMetadata] = Field(..., description="List of columns")


class ColumnMapping(BaseModel):
    source_column: str = Field(..., description="Source column name")
    target_column: str = Field(..., description="Target column name")


class ValidationRequest(BaseModel):
    source_sql: str = Field(..., description="Source system SQL query")
    target_sql: str = Field(..., description="Target system SQL query")
    source_schema: TableSchema = Field(..., description="Source table schema")
    target_schema: TableSchema = Field(..., description="Target table schema")
    mappings: Optional[List[ColumnMapping]] = Field(
        default=None,
        description="Optional source-to-target column mappings"
    )


class ValidationIssue(BaseModel):
    category: Literal["column", "datatype", "transformation", "join", "mapping"]
    severity: Literal["HIGH", "MEDIUM", "LOW"]
    message: str


class ValidationResponse(BaseModel):
    status: str = Field(..., description="Validation status")
    issues: List[ValidationIssue] = Field(
        default_factory=list,
        description="Structured validation issues"
    )
    summary: str = Field(..., description="High-level summary of findings")