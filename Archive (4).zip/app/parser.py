from typing import Any, Dict, List, Optional
import sqlglot
from sqlglot import exp


def normalize_identifier(identifier: str) -> str:
    """
    Remove BigQuery-style backticks and surrounding whitespace.
    """
    return identifier.strip().replace("`", "")


def parse_sql(sql: str, dialect: str = "bigquery") -> exp.Expression:
    """
    Parse SQL into a sqlglot expression tree.
    Default dialect is BigQuery because target SQL may use backticks.
    """
    return sqlglot.parse_one(sql, read=dialect)


def extract_select_columns(parsed: exp.Expression) -> List[str]:
    """
    Extract selected columns or aliases from the SELECT clause.
    """
    columns: List[str] = []

    select_exprs = parsed.expressions or []
    for item in select_exprs:
        alias = item.alias_or_name
        if alias:
            columns.append(alias)
        else:
            columns.append(item.sql())

    return columns


def extract_tables(parsed: exp.Expression) -> List[str]:
    """
    Extract physical table names referenced in the query, without aliases.
    Returns fully qualified names when available.
    Example:
      `project.dataset.table` -> project.dataset.table
      schema.table alias -> schema.table
    """
    tables: List[str] = []

    for table in parsed.find_all(exp.Table):
        parts = [part for part in [table.catalog, table.db, table.name] if part]
        table_name = ".".join(parts)
        table_name = normalize_identifier(table_name)

        if table_name and table_name not in tables:
            tables.append(table_name)

    return tables


def extract_joins(parsed: exp.Expression) -> List[Dict[str, Any]]:
    """
    Extract join type, joined table, and join condition.
    """
    joins: List[Dict[str, Any]] = []

    for join in parsed.find_all(exp.Join):
        join_table = None
        if join.this:
            if isinstance(join.this, exp.Table):
                parts = [
                    part for part in [join.this.catalog, join.this.db, join.this.name]
                    if part
                ]
                join_table = normalize_identifier(".".join(parts))
            else:
                join_table = join.this.sql()

        joins.append(
            {
                "join_type": join.args.get("kind", "JOIN"),
                "table": join_table,
                "condition": join.args.get("on").sql() if join.args.get("on") else None,
            }
        )

    return joins


def extract_where_clause(parsed: exp.Expression) -> Optional[str]:
    """
    Extract WHERE clause if present.
    """
    where = parsed.args.get("where")
    return where.sql() if where else None


def extract_functions(parsed: exp.Expression) -> List[str]:
    """
    Extract SQL functions used in the query.
    Example: CAST, TRIM, COALESCE
    """
    functions: List[str] = []

    for node in parsed.walk():
        if isinstance(node, exp.Func):
            func_name = node.sql_name()
            if func_name not in functions:
                functions.append(func_name)

    return functions


def analyze_sql(sql: str, dialect: str = "bigquery") -> Dict[str, Any]:
    """
    Parse and return a structured summary of the SQL.
    """
    parsed = parse_sql(sql, dialect=dialect)

    return {
        "columns": extract_select_columns(parsed),
        "tables": extract_tables(parsed),
        "joins": extract_joins(parsed),
        "where": extract_where_clause(parsed),
        "functions": extract_functions(parsed),
    }


def extract_source_and_target_objects(
    source_sql: str,
    target_sql: str,
    source_dialect: str = "teradata",
    target_dialect: str = "bigquery",
) -> Dict[str, List[str]]:
    """
    Extract referenced table/object names from both source and target SQL.
    """
    source_analysis = analyze_sql(source_sql, dialect=source_dialect)
    target_analysis = analyze_sql(target_sql, dialect=target_dialect)

    return {
        "source_objects": source_analysis["tables"],
        "target_objects": target_analysis["tables"],
    }