from typing import Dict, Any, List, Optional
from app.parser import analyze_sql
from app.models import TableSchema, ColumnMapping


def build_mapping_dict(mappings: Optional[List[ColumnMapping]]) -> Dict[str, str]:
    if not mappings:
        return {}
    return {m.source_column: m.target_column for m in mappings}


def normalize_columns_with_mappings(
    columns: List[str], mapping_dict: Dict[str, str]
) -> List[str]:
    return [mapping_dict.get(col, col) for col in columns]


def normalize_text_with_mappings(text: Optional[str], mapping_dict: Dict[str, str]) -> Optional[str]:
    if text is None:
        return None

    normalized = text
    for source_col in sorted(mapping_dict.keys(), key=len, reverse=True):
        target_col = mapping_dict[source_col]
        normalized = normalized.replace(source_col, target_col)

    return normalized


def compare_columns(
    source_cols: List[str],
    target_cols: List[str],
    mapping_dict: Dict[str, str],
) -> List[Dict[str, str]]:
    issues = []

    normalized_source = normalize_columns_with_mappings(source_cols, mapping_dict)

    missing = set(normalized_source) - set(target_cols)
    extra = set(target_cols) - set(normalized_source)

    if missing:
        issues.append({
            "category": "column",
            "severity": "HIGH",
            "message": f"Missing columns in target: {sorted(list(missing))}",
        })

    if extra:
        issues.append({
            "category": "column",
            "severity": "MEDIUM",
            "message": f"Extra columns in target: {sorted(list(extra))}",
        })

    return issues


def compare_functions(source_funcs: List[str], target_funcs: List[str]) -> List[Dict[str, str]]:
    issues = []

    missing = set(source_funcs) - set(target_funcs)
    extra = set(target_funcs) - set(source_funcs)

    if missing:
        issues.append({
            "category": "transformation",
            "severity": "HIGH",
            "message": f"Functions missing in target: {sorted(list(missing))}",
        })

    if extra:
        issues.append({
            "category": "transformation",
            "severity": "LOW",
            "message": f"Extra functions in target: {sorted(list(extra))}",
        })

    return issues


def compare_tables(source_tables: List[str], target_tables: List[str]) -> List[Dict[str, str]]:
    if set(source_tables) != set(target_tables):
        return [{
            "category": "join",
            "severity": "HIGH",
            "message": f"Table mismatch: source={source_tables}, target={target_tables}",
        }]
    return []


def compare_where(
    source_where: Optional[str],
    target_where: Optional[str],
    mapping_dict: Dict[str, str],
) -> List[Dict[str, str]]:
    normalized_source_where = normalize_text_with_mappings(source_where, mapping_dict)

    if normalized_source_where != target_where:
        return [{
            "category": "join",
            "severity": "MEDIUM",
            "message": f"WHERE clause mismatch: source={normalized_source_where}, target={target_where}",
        }]
    return []


def build_schema_dict(schema: TableSchema) -> Dict[str, str]:
    return {col.name: col.datatype for col in schema.columns}


def normalize_datatype(dtype: str) -> str:
    dtype = dtype.upper()
    mapping = {
        "INTEGER": "INT64",
        "INT": "INT64",
        "BIGINT": "INT64",
        "SMALLINT": "INT64",
        "VARCHAR": "STRING",
        "CHAR": "STRING",
        "TEXT": "STRING",
        "FLOAT": "FLOAT64",
        "DOUBLE": "FLOAT64",
        "BOOLEAN": "BOOL",
    }
    return mapping.get(dtype, dtype)


def validate_mappings(
    source_schema: TableSchema,
    target_schema: TableSchema,
    mappings: Optional[List[ColumnMapping]],
) -> List[Dict[str, str]]:
    issues = []

    source_cols = {col.name for col in source_schema.columns}
    target_cols = {col.name for col in target_schema.columns}

    if not mappings:
        return [{
            "category": "mapping",
            "severity": "LOW",
            "message": "No mappings provided",
        }]

    for mapping in mappings:
        if mapping.source_column not in source_cols:
            issues.append({
                "category": "mapping",
                "severity": "HIGH",
                "message": f"Source mapping column missing: {mapping.source_column}",
            })

        if mapping.target_column not in target_cols:
            issues.append({
                "category": "mapping",
                "severity": "HIGH",
                "message": f"Target mapping column missing: {mapping.target_column}",
            })

    return issues


def validate_datatypes(
    source_schema: TableSchema,
    target_schema: TableSchema,
    mappings: Optional[List[ColumnMapping]],
) -> List[Dict[str, str]]:
    issues = []

    if not mappings:
        return issues

    source_dict = build_schema_dict(source_schema)
    target_dict = build_schema_dict(target_schema)

    for mapping in mappings:
        source_col = mapping.source_column
        target_col = mapping.target_column

        if source_col not in source_dict or target_col not in target_dict:
            continue

        source_dtype = normalize_datatype(source_dict[source_col])
        target_dtype = normalize_datatype(target_dict[target_col])

        if source_dtype != target_dtype:
            issues.append({
                "category": "datatype",
                "severity": "HIGH",
                "message": (
                    f"Datatype mismatch for {source_col} -> {target_col}: "
                    f"source={source_dtype}, target={target_dtype}"
                ),
            })

    return issues


def validate_sql(
    source_sql: str,
    target_sql: str,
    source_schema: TableSchema,
    target_schema: TableSchema,
    mappings: Optional[List[ColumnMapping]],
) -> Dict[str, Any]:
    source = analyze_sql(source_sql)
    target = analyze_sql(target_sql)

    mapping_dict = build_mapping_dict(mappings)

    issues = []
    issues.extend(compare_columns(source["columns"], target["columns"], mapping_dict))
    issues.extend(compare_functions(source["functions"], target["functions"]))
    issues.extend(compare_tables(source["tables"], target["tables"]))
    issues.extend(compare_where(source["where"], target["where"], mapping_dict))
    issues.extend(validate_mappings(source_schema, target_schema, mappings))
    issues.extend(validate_datatypes(source_schema, target_schema, mappings))

    high_count = sum(1 for issue in issues if issue["severity"] == "HIGH")
    medium_count = sum(1 for issue in issues if issue["severity"] == "MEDIUM")
    low_count = sum(1 for issue in issues if issue["severity"] == "LOW")

    summary = (
        f"Validation completed: {len(issues)} issue(s) found "
        f"({high_count} HIGH, {medium_count} MEDIUM, {low_count} LOW)."
    )

    return {
        "issues": issues,
        "summary": summary,
    }